# backend/app/database.py
import sqlite3
import time
import os
import shutil
from .config import DB_NAME

BASE_DIR = os.path.dirname(__file__)  # app/
DB_PATH = os.path.join(os.path.dirname(__file__), '..', DB_NAME)  # ../keystroke.db
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), '..', 'schema.sql')

# A simple connection factory used by routers (thread-safe not required for demo)
def get_conn():
    # Use check_same_thread=False so FastAPI threads can share conn if needed
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

# Backwards-compatible wrapper name used in some places: get_db()
def get_db():
    return get_conn()

def now_ts():
    return int(time.time())

def init_db(create_if_missing=True):
    """
    Initialize DB from schema.sql. If the DB file is corrupt, create a backup
    and create a fresh DB using the schema.
    """
    # Ensure schema exists
    if not os.path.exists(SCHEMA_PATH):
        raise FileNotFoundError(f"schema.sql not found at {SCHEMA_PATH}")

    # If DB is missing and create_if_missing True -> create fresh
    if not os.path.exists(DB_PATH):
        conn = get_conn()
        with open(SCHEMA_PATH, 'r', encoding='utf8') as f:
            cur = conn.cursor()
            cur.executescript(f.read())
            conn.commit()
            conn.close()
        return

    # If DB exists, run PRAGMA integrity_check
    try:
        conn = get_conn()
        cur = conn.cursor()
        ok = cur.execute("PRAGMA integrity_check").fetchall()
        # 'ok' expected to be [('ok',)] if healthy
        if not ok or ok[0][0] != 'ok':
            raise sqlite3.DatabaseError("PRAGMA integrity_check failed: %r" % (ok,))
        conn.close()
    except sqlite3.DatabaseError:
        # backup corrupt DB
        timestamp = time.strftime("%Y%m%dT%H%M%S")
        bak = DB_PATH + ".corrupt_backup_" + timestamp
        shutil.copy2(DB_PATH, bak)
        # create new DB from schema
        conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        with open(SCHEMA_PATH, 'r', encoding='utf8') as f:
            cur = conn.cursor()
            cur.executescript(f.read())
            conn.commit()
            conn.close()
        # raise a warning file for debugging
        with open(os.path.join(os.path.dirname(__file__), '..', 'db_repair.log'), 'w', encoding='utf8') as f:
            f.write(f"Backed up corrupt DB to: {bak}\nCreated fresh DB from schema.sql\n")
        return
    except Exception as e:
        # re-raise unexpected issues
        raise

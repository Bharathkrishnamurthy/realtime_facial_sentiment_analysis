﻿# app/candidate_routes.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import app.session_service as session_service
import app.database as database
from app.models import Event


router = APIRouter(prefix="/candidate")

# Request Model for /start (already present in your file)
class StartRequest(BaseModel):
    token: str

@router.post("/start")
def start_test(req: StartRequest):
    db = database.get_db()
    session_id, test_id = session_service.create_session_for_token(db, req.token)
    if not session_id:
        raise HTTPException(status_code=404, detail="Invalid Token")
    questions = session_service.get_questions_for_test(db, test_id)
    return {"status": "ok", "session_id": session_id, "test_id": test_id, "questions": questions}


# Request model for submit_answer
class SubmitAnswerRequest(BaseModel):
    session_id: str
    question_id: int
    final_text: Optional[str] = ""
    events: List[Event] = []

@router.post("/submit_answer")
def submit_answer(req: SubmitAnswerRequest):
    db = database.get_db()
    # Ensure session exists and is active (or mark it active if first answer)
    s = db.execute("SELECT * FROM sessions WHERE session_id = ?", (req.session_id,)).fetchone()
    if not s:
        raise HTTPException(status_code=404, detail="session not found")
    # Optionally set started_at / status if not set
    try:
        # If your sessions table has started_at / status column names, adjust if different.
        db.execute("UPDATE sessions SET started_at = COALESCE(started_at, datetime('now')), status = COALESCE(status, 'active') WHERE session_id = ?", (req.session_id,))
        db.commit()
    except Exception:
        # ignore if columns not present or different schema
        pass

    # Save answer + minimal feature log using session_service helper
    try:
        session_service.save_answer_and_biometrics(db, req.session_id, req.question_id, req.final_text, [e.dict() for e in req.events] if req.events else [])
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"failed to save answer: {e}")

    return {"status": "ok", "note": "features extracted"}
class FinishRequest(BaseModel):
    session_id: str

@router.post("/finish")
def finish_test(req: FinishRequest):
    db = database.get_db()
    # verify session exists
    s = db.execute("SELECT * FROM sessions WHERE session_id = ?", (req.session_id,)).fetchone()
    if not s:
        raise HTTPException(status_code=404, detail="session not found")

    # call the session_service finish function that returns (score, authenticity)
    try:
        score, authenticity = session_service.finish_session(db, req.session_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"finish failed: {e}")

    return {"status": "ok", "session_id": req.session_id, "score": score, "authenticity": authenticity}
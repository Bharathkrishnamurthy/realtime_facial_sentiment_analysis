﻿from fastapi import APIRouter
router = APIRouter()
@router.get("/_hr_stub")
def _hr_stub():
    return {"ok": True, "note": "HR routes are stubbed temporarily. Restore interview_routes.py.bak to get full functionality back."}

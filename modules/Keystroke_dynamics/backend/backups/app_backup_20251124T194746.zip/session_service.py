# backend/app/session_service.py
import uuid
from datetime import datetime, timezone
import json

def _now_str():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

def extract_features(events):
    """Return dict: {mean_hold, mean_dd, num_events}"""
    if not events:
        return {"mean_hold": None, "mean_dd": None, "num_events": 0}
    holds = []
    last_down = {}
    for e in events:
        t = e.get("ts")
        typ = e.get("type")
        key = e.get("key")
        if typ == "keydown":
            last_down[key] = t
        elif typ == "keyup" and key in last_down:
            holds.append(t - last_down[key])
            del last_down[key]
    # digraphs: time between successive keydown timestamps
    dd = []
    prev_down = None
    for e in events:
        if e.get("type") == "keydown":
            if prev_down is not None:
                dd.append(e["ts"] - prev_down)
            prev_down = e["ts"]
    def mean(arr):
        return sum(arr)/len(arr) if arr else None
    return {"mean_hold": mean(holds), "mean_dd": mean(dd), "num_events": len(events)}

def compute_template_from_samples(samples):
    """Given list of samples (each sample is events list), return template {mean_hold, mean_dd, n_samples}"""
    feats = [extract_features(s) for s in samples if s]
    if not feats:
        return None
    # compute averages ignoring None
    hold_vals = [f["mean_hold"] for f in feats if f["mean_hold"] is not None]
    dd_vals = [f["mean_dd"] for f in feats if f["mean_dd"] is not None]
    mean_hold = sum(hold_vals)/len(hold_vals) if hold_vals else None
    mean_dd = sum(dd_vals)/len(dd_vals) if dd_vals else None
    return {"mean_hold": mean_hold, "mean_dd": mean_dd, "n_samples": len(feats)}

from . import database      # your existing database helper
# If your DB helper uses a function name other than get_db(), adjust below.

# add / replace this function in app/session_service.py

def save_answer_and_biometrics(db, session_id, question_id, final_text, events):
    """
    Save candidate answer + a minimal feature log.
    Args:
      db: sqlite3.Connection (with execute/commit)
      session_id: string
      question_id: int
      final_text: string
      events: list of event dicts

    Returns: True on success, raises exception on failure.
    """
    import json
    from datetime import datetime

    def _now_str():
        return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    ts = _now_str()

    # Insert into answers table: try common column names, else raise
    try:
        db.execute(
            "INSERT INTO answers (session_id, question_id, final_text, created_at) VALUES (?, ?, ?, ?)",
            (session_id, question_id, final_text or "", ts),
        )
        db.commit()
    except Exception:
        # fallback: try 'answer_text' name (some schemas)
        try:
            db.execute(
                "INSERT INTO answers (session_id, question_id, answer_text, created_at) VALUES (?, ?, ?, ?)",
                (session_id, question_id, final_text or "", ts),
            )
            db.commit()
        except Exception:
            # re-raise the original error to make debugging visible
            raise

    # Optionally store a compact JSON summary into feature_logs (if table present).
    try:
        meta = {"events_count": len(events) if events else 0}
        db.execute(
            "INSERT INTO feature_logs (session_id, question_id, meta, created_at) VALUES (?, ?, ?, ?)",
            (session_id, question_id, json.dumps(meta), ts),
        )
        db.commit()
    except Exception:
        # If feature_logs doesn't exist or schema differs, ignore silently.
        pass

    return True


def create_session_for_token(db, token):
    """
    Look up assignments table for token -> (candidate_id, test_id).
    If found, insert a session row and mark it active (started_at) and return (session_id, test_id).
    If not found, return (None, None).
    This function is robust to different sessions table schemas.
    """
    cur = db.execute(
        "SELECT id, candidate_id, test_id FROM assignments WHERE token = ? LIMIT 1",
        (token,)
    )
    row = cur.fetchone()
    if not row:
        return None, None

    # row may be sqlite3.Row or tuple
    try:
        assignment_id = row["id"]
        candidate_id = row["candidate_id"]
        test_id = row["test_id"]
    except Exception:
        assignment_id = row[0]
        candidate_id = row[1]
        test_id = row[2]

    session_id = str(uuid.uuid4())
    ts = _now_str()

    # Try to insert using a common schema; if it fails try other variants
    inserted = False
    last_exc = None
    try:
        db.execute(
            "INSERT INTO sessions (session_id, test_id, candidate_id, status, started_at) VALUES (?, ?, ?, ?, ?)",
            (session_id, test_id, candidate_id, "active", ts),
        )
        db.commit()
        inserted = True
    except Exception as e:
        last_exc = e

    if not inserted:
        try:
            db.execute(
                "INSERT INTO sessions (session_id, test_id, candidate_id, status, created_at) VALUES (?, ?, ?, ?, ?)",
                (session_id, test_id, candidate_id, "active", ts),
            )
            db.commit()
            inserted = True
        except Exception as e:
            last_exc = e

    if not inserted:
        try:
            # older/simpler schema
            db.execute(
                "INSERT INTO sessions (session_id, test_id, status, timestamp) VALUES (?, ?, ?, ?)",
                (session_id, test_id, "active", int(datetime.utcnow().timestamp())),
            )
            db.commit()
            inserted = True
        except Exception as e:
            last_exc = e

    if not inserted:
        # give up with informative exception
        raise RuntimeError("Failed to insert session row; last error: %r" % (last_exc,))

    # Ensure status/started_at are set (in case insert used a variant without started_at)
    try:
        # Try the common update first
        db.execute("UPDATE sessions SET status = ?, started_at = ? WHERE session_id = ?", ("active", ts, session_id))
        db.commit()
    except Exception:
        try:
            db.execute("UPDATE sessions SET status = ?, created_at = ? WHERE session_id = ?", ("active", ts, session_id))
            db.commit()
        except Exception:
            # best-effort: ignore if DB doesn't have these columns
            pass

    return session_id, test_id

def get_questions_for_test(db, test_id):
    """
    Return list of dicts: {question_id, text, seq}
    Uses test_questions -> questions join.
    Robust to sqlite3.Row or tuple rows and to schemas where seq may be missing.
    """
    # Query: join test_questions -> questions. If seq column missing, still return text + id.
    try:
        q = db.execute(
            """
            SELECT q.id AS question_id, q.text AS text, tq.seq AS seq
            FROM test_questions tq
            JOIN questions q ON q.id = tq.question_id
            WHERE tq.test_id = ?
            ORDER BY tq.seq ASC
            """,
            (test_id,)
        ).fetchall()
    except Exception:
        # fallback (no seq column or different schema) - select without seq
        q = db.execute(
            """
            SELECT q.id AS question_id, q.text AS text
            FROM test_questions tq
            JOIN questions q ON q.id = tq.question_id
            WHERE tq.test_id = ?
            """,
            (test_id,)
        ).fetchall()

    results = []
    for r in q:
        # r may be sqlite3.Row with keys or a tuple
        try:
            question_id = r["question_id"]
            text = r["text"]
            seq = r.get("seq", None) if hasattr(r, "get") else (r["seq"] if "seq" in r.keys() else None)
        except Exception:
            # tuple fallback: enumerate columns by position
            if len(r) >= 2:
                question_id = r[0]
                text = r[1]
                seq = r[2] if len(r) > 2 else None
            else:
                # very defensive fallback
                question_id = None
                text = None
                seq = None

        results.append({"question_id": question_id, "text": text, "seq": seq})
    return results


def finish_session(db, session_id):
    """
    Mark session finished and compute a simple score:
      score = (#answers for session) / (#questions in the associated test)
    Return JSON-friendly tuple: (score_float_between_0_1, authenticity_str)

    This function is robust to different session table schemas:
      - New schema: sessions(id, session_id, assignment_id, candidate_id, test_id, started_at, finished_at, status)
      - Old schema: sessions(session_id, user_id, question_id, timestamp, score, verdict, paste_flag, notes)
    """
    from datetime import datetime

    def _now_str():
        return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    # Try to locate the session row in a schema-agnostic way
    cur = db.execute("SELECT * FROM sessions WHERE session_id = ? LIMIT 1", (session_id,))
    s = cur.fetchone()
    if not s:
        # fallback: maybe session stored in other tables or different col name
        raise ValueError("session not found")

    # reading test_id in a robust way
    try:
        test_id = s["test_id"] if "test_id" in s.keys() else s[4] if len(s) > 4 else None
    except Exception:
        # tuple-like row fallback
        try:
            test_id = s[4]
        except Exception:
            test_id = None

    # If we can't determine test_id, try to find via assignment_id -> assignments.test_id
    if not test_id:
        try:
            assignment_id = s["assignment_id"] if "assignment_id" in s.keys() else None
            if assignment_id:
                a = db.execute("SELECT test_id FROM assignments WHERE id = ? LIMIT 1", (assignment_id,)).fetchone()
                if a:
                    test_id = a["test_id"] if "test_id" in a.keys() else a[0]
        except Exception:
            test_id = None

    # Count answers for this session
    try:
        answers_count = db.execute("SELECT COUNT(*) as c FROM answers WHERE session_id = ?", (session_id,)).fetchone()
        answers_count = answers_count["c"] if "c" in answers_count.keys() else answers_count[0]
    except Exception:
        # If answers table missing, treat as zero
        answers_count = 0

    # Count total questions in test (if test_id known)
    total_questions = None
    if test_id:
        try:
            tq = db.execute("SELECT COUNT(*) as c FROM test_questions WHERE test_id = ?", (test_id,)).fetchone()
            total_questions = tq["c"] if "c" in tq.keys() else tq[0]
        except Exception:
            total_questions = None

    # Compute score safely
    score = 0.0
    if total_questions and total_questions > 0:
        score = float(answers_count) / float(total_questions)
    else:
        # if we can't determine total questions, treat score = 0 if no answers, else 1
        score = 1.0 if answers_count > 0 else 0.0

    # Decide simple authenticity rule
    if score >= 0.6:
        authenticity = "authentic"
    elif score > 0:
        authenticity = "suspicious"
    else:
        authenticity = "no_answers"

    # Update session row: try multiple possible schemas
    now = _now_str()
    updated = False
    # Try new schema: columns 'status' and 'finished_at' or 'updated_at'
    try:
        # prefer finished_at/updated_at if present
        cols = [c[0] for c in db.execute("PRAGMA table_info(sessions)").fetchall()]
        if "finished_at" in cols and "status" in cols:
            db.execute("UPDATE sessions SET status = ?, finished_at = ?, updated_at = ? WHERE session_id = ?",
                       ("finished", now, now, session_id))
            updated = True
        elif "finished_at" in cols:
            db.execute("UPDATE sessions SET finished_at = ?, status = ? WHERE session_id = ?",
                       (now, "finished", session_id))
            updated = True
        elif "status" in cols:
            # maybe status only
            db.execute("UPDATE sessions SET status = ?, updated_at = ? WHERE session_id = ?",
                       ("finished", now, session_id))
            updated = True
    except Exception:
        updated = False

    # Fallback to older schema (where session row may have 'timestamp','verdict','score')
    if not updated:
        try:
            cols = [c[0] for c in db.execute("PRAGMA table_info(sessions)").fetchall()]
            if "verdict" in cols and "score" in cols:
                db.execute("UPDATE sessions SET score = ?, verdict = ? WHERE session_id = ?",
                           (score, authenticity, session_id))
                updated = True
            elif "score" in cols:
                db.execute("UPDATE sessions SET score = ? WHERE session_id = ?", (score, session_id))
                updated = True
        except Exception:
            updated = False

    # Last resort: attempt to insert an audit into feature_logs or a sessions_history table (if exists)
    try:
        db.commit()
    except Exception:
        pass

    return score, authenticity

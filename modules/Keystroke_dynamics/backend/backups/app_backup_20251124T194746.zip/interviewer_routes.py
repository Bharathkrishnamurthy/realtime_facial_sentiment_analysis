# backend/app/interviewer_routes.py
from fastapi import APIRouter
import app.database as database

router = APIRouter(prefix="/interviewer")

@router.get("/summary")
def get_summary():
    db = database.get_db()
    rows = db.execute("SELECT id, session_id, candidate_id, test_id, started_at, finished_at, status FROM sessions ORDER BY id DESC LIMIT 50").fetchall()
    sessions = []
    for r in rows:
        try:
            # sqlite3.Row supports keys
            sessions.append({k: r[k] for k in r.keys()})
        except Exception:
            sessions.append(tuple(r))
    total_sessions = db.execute("SELECT COUNT(*) as c FROM sessions").fetchone()[0]
    total_answers = 0
    try:
        total_answers = db.execute("SELECT COUNT(*) as c FROM answers").fetchone()[0]
    except:
        total_answers = 0
    return {"total_sessions": total_sessions, "total_answers": total_answers, "sessions": sessions}

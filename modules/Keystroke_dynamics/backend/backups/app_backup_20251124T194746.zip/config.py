# app/config.py
import os
# app/config.py

MODEL_VERSION = "v1.0"

# Enrollment quality limits
MIN_ENROLL_CHARS = 20             # minimum characters in final_text
MIN_ENROLL_KEY_EVENTS = 20        # minimum raw key events

# SQLite DB name (kept same as before)
DB_NAME = os.getenv("KS_DB_NAME", "keystroke.db")

# Thresholds for matcher (can be tuned later without touching logic)
ACCEPT_THRESHOLD = float(os.getenv("KS_ACCEPT_T", "0.70"))
REVIEW_THRESHOLD = float(os.getenv("KS_REVIEW_T", "0.55"))

# Model/version label so you know which embedding version was used
MODEL_VERSION = os.getenv("KS_MODEL_VERSION", "ks_v1_robust64")

# Enrollment quality rules (professional touch)
MIN_ENROLL_CHARS = int(os.getenv("KS_MIN_ENROLL_CHARS", "40"))
MIN_ENROLL_KEY_EVENTS = int(os.getenv("KS_MIN_ENROLL_KEY_EVENTS", "60"))

﻿# matcher.py -- mean-template matcher + cosine similarity
import numpy as np

def bytes_to_vector(b):
    if b is None:
        return None
    try:
        return np.frombuffer(b, dtype=np.float32)
    except Exception:
        try:
            return np.frombuffer(bytes(b), dtype=np.float32)
        except Exception:
            return None

def cosine_similarity(a, b):
    if a is None or b is None:
        return 0.0
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))

def decide_score_and_verdict(feature_vector, templates, paste_flag):
    """
    Now we compute the MEAN template (average of stored templates) and compare
    the incoming feature_vector to that mean. This reduces noise from small
    variations across enrollment samples.
    templates: list of numpy arrays
    """
    # no templates
    if not templates:
        return {"score": 0.0, "verdict": "no_template"}

    # filter out None
    clean = [t for t in templates if t is not None and t.size == feature_vector.size]
    if not clean:
        return {"score": 0.0, "verdict": "no_template"}

    # compute mean template
    mean_t = np.mean(np.stack(clean, axis=0), axis=0)

    # similarity to mean
    score = cosine_similarity(feature_vector, mean_t)

    # malpractice override
    if paste_flag:
        return {"score": score, "verdict": "suspicious_paste"}

    # thresholds (phase-1, more permissive)
    if score >= 0.70:
        return {"score": score, "verdict": "accepted"}
    elif score >= 0.55:
        return {"score": score, "verdict": "review"}
    else:
        return {"score": score, "verdict": "rejected"}

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import app.database as database
import json
from app.session_service import compute_template_from_samples, _now_str

router = APIRouter(prefix="/candidate")

class EnrollSampleReq(BaseModel):
    token: str = None
    session_id: str = None
    events: list

class EnrollFinishReq(BaseModel):
    token: str = None
    session_id: str = None
    finalize: bool = True

@router.post("/enroll")
def enroll_sample(req: EnrollSampleReq):
    db = database.get_db()
    candidate_id = None
    # try assignment token
    if req.token:
        row = db.execute("SELECT candidate_id FROM assignments WHERE token = ? LIMIT 1", (req.token,)).fetchone()
        if row:
            candidate_id = row["candidate_id"] if "candidate_id" in row.keys() else row[0]
    # try session id fallback
    if not candidate_id and req.session_id:
        row = db.execute("SELECT candidate_id FROM sessions WHERE session_id = ? LIMIT 1", (req.session_id,)).fetchone()
        if row:
            candidate_id = row["candidate_id"] if "candidate_id" in row.keys() else row[0]
    if not candidate_id:
        raise HTTPException(status_code=404, detail="Candidate not found for token/session")

    # persist sample into profiles.template as JSON {samples: [ ... ]}
    prof = db.execute("SELECT id, template FROM profiles WHERE user_id = ? LIMIT 1", (str(candidate_id),)).fetchone()
    if not prof:
        template_obj = {"samples": [req.events]}
        db.execute("INSERT INTO profiles (user_id, created_at, template) VALUES (?, ?, ?)", (str(candidate_id), _now_str(), json.dumps(template_obj)))
        db.commit()
        samples_count = 1
    else:
        prof_id = prof["id"] if "id" in prof.keys() else prof[0]
        cur_template = json.loads(prof["template"]) if prof["template"] else {"samples": []}
        cur_template.setdefault("samples", []).append(req.events)
        db.execute("UPDATE profiles SET template = ? WHERE id = ?", (json.dumps(cur_template), prof_id))
        db.commit()
        samples_count = len(cur_template["samples"])
    return {"status": "ok", "samples_count": samples_count}

@router.post("/enroll_finish")
def enroll_finish(req: EnrollFinishReq):
    db = database.get_db()
    candidate_id = None
    if req.token:
        row = db.execute("SELECT candidate_id FROM assignments WHERE token = ? LIMIT 1", (req.token,)).fetchone()
        if row:
            candidate_id = row["candidate_id"] if "candidate_id" in row.keys() else row[0]
    if not candidate_id and req.session_id:
        row = db.execute("SELECT candidate_id FROM sessions WHERE session_id = ? LIMIT 1", (req.session_id,)).fetchone()
        if row:
            candidate_id = row["candidate_id"] if "candidate_id" in row.keys() else row[0]
    if not candidate_id:
        raise HTTPException(status_code=404, detail="Candidate not found")
    prof = db.execute("SELECT id, template FROM profiles WHERE user_id = ? LIMIT 1", (str(candidate_id),)).fetchone()
    if not prof:
        raise HTTPException(status_code=404, detail="No enrollment samples for candidate")
    prof_id = prof["id"] if "id" in prof.keys() else prof[0]
    template_json = json.loads(prof["template"]) if prof["template"] else {"samples": []}
    samples = template_json.get("samples", [])
    tpl = compute_template_from_samples(samples)
    template_json["template_features"] = tpl
    db.execute("UPDATE profiles SET template = ? WHERE id = ?", (json.dumps(template_json), prof_id))
    db.commit()
    return {"status": "ok", "template": tpl}

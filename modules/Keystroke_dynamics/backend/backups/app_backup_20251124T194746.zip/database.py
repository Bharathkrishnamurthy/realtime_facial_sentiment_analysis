# database.py
import sqlite3
import time
import os

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'keystroke.db')

def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    schema_path = os.path.join(os.path.dirname(__file__), '..', 'schema.sql')
    with open(schema_path, 'r', encoding='utf-8') as f:
        cur.executescript(f.read())
    conn.commit()
    conn.close()

def now_ts():
    return int(time.time())
# --- helper expected by candidate_routes / session_service ---
def get_db():
    """
    Return a sqlite3.Connection with row_factory set to sqlite3.Row.
    This is used by candidate_routes and others which expect dict-like rows.
    """
    import sqlite3, os
    # compute DB path relative to this file
    db_path = os.path.join(os.path.dirname(__file__), "keystroke.db")
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn
